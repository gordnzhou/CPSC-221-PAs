
#include "stats.h"

stats::stats(PNG& im) {
    /* Your code here!! */
}

long stats::getSum(char channel, pair<int, int> ul, int dim) {
    /* Your code here!! */
    return 0;
}

long stats::getSumSq(char channel, pair<int, int> ul, int dim) {
    /* Your code here!! */
    return 0;
}

long stats::rectArea(int dim) {
    /* Your code here!! */
    return 0;
}

// given a rectangle, compute its sum of squared deviations from mean, over all color channels.
// see written specification for a description of this function.
double stats::getVar(pair<int, int> ul, int dim) {
    /* Your code here!! */
    return 0;
}

RGBAPixel stats::getAvg(pair<int, int> ul, int dim) {
    /* Your code here!! */
    return RGBAPixel();
}
