#define CATCH_CONFIG_MAIN
#include "cs221util/catch.hpp"